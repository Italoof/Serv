#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QDebug>

namespace Ui {
class MainWindow;
}
/**
 * @brief The MainWindow class É a Janela Principal do cliente produtor
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

    int id;
    QString str;
    int nTimers;
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void timerEvent(QTimerEvent *event);

public slots:
    /**
     * @brief putData Envia os Dados
     */
    void putData();
    /**
     * @brief tcpConnect Conecta com ip no servidor
     */
    void tcpConnect();
    /**
     * @brief tcpDisconnect Disconecta com o servidor
     */
    void tcpDisconnect();
    /**
     * @brief startButtom Inicia o envio de Dados
     */
    void startButtom();
    /**
     * @brief stopButtom Pausa o envio de dados
     */
    void stopButtom();
private:
    Ui::MainWindow *ui;
    QTcpSocket *socket;
};

#endif // MAINWINDOW_H
