var searchData=
[
  ['startbuttom',['startButtom',['../class_main_window.html#a6ab394a0732eb4e391a5b1d2348ebbee',1,'MainWindow']]],
  ['stopbuttom',['stopButtom',['../class_main_window.html#a7282347b51f017086870cd2cc3b99846',1,'MainWindow']]]
];
