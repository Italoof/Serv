var searchData=
[
  ['recebedados',['recebeDados',['../class_plotter.html#ad3fe6a192de0af28c7928738cdbd561b',1,'Plotter']]]
];
