var searchData=
[
  ['getdata',['getData',['../class_main_window.html#a4a2ddf4cf2ec8e240cc340416b1df792',1,'MainWindow']]]
];
