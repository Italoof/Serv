var searchData=
[
  ['emitedados',['emiteDados',['../class_main_window.html#a008cc90e0b6c8888d569ed7ae86c693c',1,'MainWindow']]]
];
