#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QDebug>
#include <vector>

namespace Ui {
class MainWindow;
}

using namespace std;

class MainWindow : public QMainWindow
{
  Q_OBJECT

    int nTimers;
    int id;

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void timerEvent(QTimerEvent * event);

public slots:
    /**
       * @brief getData Recebe 30 dados do servidor e armazena os valores e os tempos dos dados
       */
      void getData();
      /**
       * @brief tcpConnect Conecta o consumidor a um ip ligado a um servidor
       */
      void tcpConnect();
      /**
       * @brief tcpDisconnect Desconecta o consumidor de um ip ligado a um servidor
       */
      void tcpDisconnect();
      /**
       * @brief startButtom Inicia o recebimento de dados
       */
      void startButtom();
      /**
       * @brief stopButtom Para o recebimento de dados
       */
      void stopButtom();
      /**
       * @brief listaIps Cria uma lista dos ips conectados ao consumidor
       */
      void listaIps();

signals:
      /**
   * @brief emiteDados É um sinal que recebe 2 vetores vector <float>
   * @return Sinais o tipo vector <float>
   */
  vector <float> emiteDados(vector<float>, vector<float>);

private:
  Ui::MainWindow *ui;
  QTcpSocket *socket;
};

#endif // MAINWINDOW_H
